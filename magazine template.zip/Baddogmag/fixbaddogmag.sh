#!/data/data/com.termux/files/usr/bin/bash
# fixbaddogmag.sh - Fix Bad Dog Entertainment website structure

echo "=== Bad Dog Entertainment Website Fixer ==="
echo "Working in: $(pwd)"

# Create directories if they don't exist
echo "Creating necessary directories..."
mkdir -p html css js assets/patterns assets/images assets/fonts

# Create netlify.toml 
echo "Creating netlify.toml..."
cat > netlify.toml << 'EOL'
[[redirects]]
  from = "/"
  to = "/index.html"
  status = 200

[[redirects]]
  from = "/article"
  to = "/html/article-template.html"
  status = 200

[[redirects]]
  from = "/category"
  to = "/html/category-template.html"
  status = 200
EOL

# Check for source files and create output files
echo "Processing HTML templates..."
for source in "Initial HTML Structure.txt" "Article Page Template.txt" "Category Page Template.txt"; do
  if [ -f "$source" ]; then
    echo "Found $source"
    case "$source" in
      "Initial HTML Structure.txt")
        cat "$source" > "index.html"
        cat "$source" > "html/index-template.html"
        echo "✓ Created index.html and template"
        ;;
      "Article Page Template.txt")
        cat "$source" > "html/article-template.html"
        echo "✓ Created article template"
        ;;
      "Category Page Template.txt")
        cat "$source" > "html/category-template.html"
        echo "✓ Created category template"
        ;;
    esac
  else
    echo "⚠ File not found: $source"
  fi
done

# Process CSS files
echo "Processing CSS files..."
if [ -f "Typography System & Design Tokens.txt" ]; then
  grep -A 1000 "/* _variables.css" "Typography System & Design Tokens.txt" > "css/_variables.css"
  grep -A 5000 "/* _typography.css" "Typography System & Design Tokens.txt" > "css/_typography.css"
  echo "✓ Created CSS variables and typography files"
fi

if [ -f "Main Stylesheet (style.css).txt" ]; then
  cat "Main Stylesheet (style.css).txt" > "css/style.css"
  echo "✓ Created main stylesheet"
fi

if [ -f "Responsive Design Enhancements.txt" ]; then
  cat "Responsive Design Enhancements.txt" > "css/responsive.css"
  echo "✓ Created responsive CSS"
fi

if [ -f "Category-Specific Components CSS.txt" ]; then
  cat "Category-Specific Components CSS.txt" > "css/category-components.css"
  echo "✓ Created category components CSS"
fi

# Process JS files
echo "Processing JavaScript files..."
for source in "Main JavaScript (main.js).txt" "Pattern Integration JavaScript.txt" "Content Filter JavaScript.txt" "Article Transitions JavaScript.txt"; do
  if [ -f "$source" ]; then
    out_file=$(echo "$source" | sed 's/ (.*).txt/.js/' | sed 's/ /-/g' | tr '[:upper:]' '[:lower:]')
    cat "$source" > "js/$out_file"
    echo "✓ Created $out_file"
  fi
done

# Fix paths in HTML files
echo "Fixing paths in files..."
for html_file in index.html html/*.html; do
  if [ -f "$html_file" ]; then
    sed -i 's|href="css/|href="/css/|g' "$html_file"
    sed -i 's|src="js/|src="/js/|g' "$html_file"
    echo "✓ Fixed paths in $html_file"
  fi
done

# Link CSS files in style.css
if [ -f "css/style.css" ]; then
  sed -i 's|@import url(.._variables.css.);|@import url("_variables.css");|g' css/style.css
  sed -i 's|@import url(.._typography.css.);|@import url("_typography.css");|g' css/style.css
  sed -i 's|@import url(.._grid.css.);|@import url("_grid.css");|g' css/style.css
  echo "✓ Fixed CSS imports"
fi

echo ""
echo "=== Website structure fix completed! ==="
echo "Your site is now ready for Netlify deployment."
#!/bin/bash
# ===========================================================================
# fix-baddogmag-paths.sh - Updated with correct path handling
# ===========================================================================

echo "=== Bad Dog Entertainment Path Fixer ==="

# Navigate to correct directory first
cd /storage/emulated/0/Internal\ storage/Baddogmag
echo "Working in directory: $(pwd)"

# First check if we're in the right place
if [ ! -d "css" ] || [ ! -d "js" ] || [ ! -d "html" ]; then
  echo "WARNING: Missing expected directories. Creating them..."
  mkdir -p css js html assets/{patterns,images,fonts}
fi

# Create or update the netlify.toml file
echo "Creating netlify.toml file..."
cat > netlify.toml << 'EOF'
# netlify.toml - Configuration for Bad Dog Entertainment

[build]
  publish = "."

[[redirects]]
  from = "/"
  to = "/index.html"
  status = 200

[[redirects]]
  from = "/article"
  to = "/html/article-template.html"
  status = 200

[[redirects]]
  from = "/category"
  to = "/html/category-template.html"
  status = 200

[build.processing]
  skip_processing = false
  
[build.processing.css]
  bundle = true
  minify = true

[build.processing.js]
  bundle = true
  minify = true

[build.processing.html]
  pretty_urls = true

[build.processing.images]
  compress = true
EOF
echo "✓ netlify.toml created"

# Create index.html in the root if html-structure.html exists
if [ -f "html/html-structure.html" ]; then
  echo "Creating root index.html from html-structure.html..."
  cp html/html-structure.html index.html
  
  # Fix paths in index.html
  sed -i 's|href="css/|href="/css/|g' index.html
  sed -i 's|src="js/|src="/js/|g' index.html
  echo "✓ index.html created and paths updated"
else
  echo "⚠ html/html-structure.html not found, creating minimal index.html..."
  cat > index.html << 'EOF'
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Bad Dog Entertainment | American Entitled Degeneracy</title>
  <link rel="stylesheet" href="/css/style.css">
</head>
<body>
  <header>
    <h1>Bad Dog Entertainment</h1>
    <nav>
      <ul>
        <li><a href="/html/category-template.html?category=chemical">Chemical Escapes</a></li>
        <li><a href="/html/category-template.html?category=afterhours">After Hours</a></li>
        <li><a href="/html/category-template.html?category=exotic">Exotic Tastes</a></li>
        <li><a href="/html/category-template.html?category=luxury">Luxury Excess</a></li>
        <li><a href="/html/category-template.html?category=degenerate">Degenerate Lifestyle</a></li>
      </ul>
    </nav>
  </header>
  <main>
    <p>"Celebrating excess since yesterday"</p>
  </main>
  <script src="/js/main.js"></script>
</body>
</html>
EOF
  echo "✓ Basic index.html created"
fi

# Fix main CSS if it exists
if [ -f "css/style.css" ]; then
  echo "Fixing CSS import paths..."
  # Replace relative imports with absolute imports
  sed -i 's|@import url(.._|@import url(/css/_|g' css/style.css
  echo "✓ CSS paths fixed"
else
  echo "⚠ css/style.css not found"
fi

# Fix paths in HTML files if they exist
if ls html/*.html 1> /dev/null 2>&1; then
  echo "Fixing paths in HTML files..."
  for file in html/*.html; do
    echo "  Processing $file..."
    sed -i 's|href="css/|href="/css/|g' "$file"
    sed -i 's|src="js/|src="/js/|g' "$file"
  done
  echo "✓ HTML file paths fixed"
else
  echo "⚠ No HTML files found in html/ directory"
fi

echo ""
echo "=== Path correction completed! ==="
echo "Your site is now ready for Netlify deployment."
echo "Upload the entire directory to Netlify for deployment."

