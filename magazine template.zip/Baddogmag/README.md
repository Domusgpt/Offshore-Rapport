# Bad Dog Entertainment Magazine
